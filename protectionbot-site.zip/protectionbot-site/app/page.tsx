
'use client';
import React from 'react';

export default function Page() {
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-4xl font-bold mb-4 text-center">ProtectionBot Legal</h1>
      <div className="grid grid-cols-2 gap-4 mb-4">
        <button onClick={() => setTab('tos')} className="p-2 bg-gray-200 rounded">Terms of Service</button>
        <button onClick={() => setTab('privacy')} className="p-2 bg-gray-200 rounded">Privacy Policy</button>
      </div>
      <div className="prose">
        <section id="tos">
          <h2>Terms of Service</h2>
          <p><strong>Last Updated:</strong> April 7, 2025</p>
          <p>Welcome to ProtectionBot. By inviting and using this bot, you agree to the following terms:</p>
          <h3>1. Usage</h3>
          <ul>
            <li>You must follow the Discord Terms of Service and Community Guidelines.</li>
            <li>The bot is provided "as is" with no guarantees of uptime or functionality.</li>
            <li>Misuse (e.g. spamming, exploiting bugs) may result in a blacklist or restriction.</li>
          </ul>
          <h3>2. Availability</h3>
          <p>We reserve the right to shut down the bot or change features at any time without notice.</p>
          <h3>3. Liability</h3>
          <p>We are not responsible for issues caused by the bot, such as data loss or moderation actions.</p>
          <p>If you have any questions, reach out via Discord.</p>
        </section>
        <section id="privacy" className="mt-10">
          <h2>Privacy Policy</h2>
          <p><strong>Last Updated:</strong> April 7, 2025</p>
          <p>Your privacy is important to us. Here's what ProtectionBot collects and how we handle it:</p>
          <h3>1. Data Collected</h3>
          <ul>
            <li>User IDs and Server IDs for internal use.</li>
            <li>Command usage logs for abuse prevention and improvements.</li>
          </ul>
          <h3>2. Data Usage</h3>
          <p>Data is used solely for bot functionality. No data is sold or shared with third parties.</p>
          <h3>3. Data Storage</h3>
          <p>Stored securely with limited developer access. Message content is not stored.</p>
          <h3>4. Data Removal</h3>
          <p>To request data removal, contact us via Discord with your User ID and Server ID.</p>
          <p>By using ProtectionBot, you consent to this privacy policy.</p>
        </section>
      </div>
    </main>
  );
}
